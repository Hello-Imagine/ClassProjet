<template>
  <router-view/>
</template>


<script>
export default {
  name: 'App'
}
</script>


<style>
#app{
  background-color: white;
}
</style>
