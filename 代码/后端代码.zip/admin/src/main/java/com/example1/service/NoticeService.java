package com.example1.service;

import java.util.Date;

public interface NoticeService {

    public void sendNotice(String title, String content);
}
