package com.example1.utils.constant;

public class DemoConstant {
}
