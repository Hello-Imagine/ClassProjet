package com.example1.utils.config;

public class DemoConfig {
}
