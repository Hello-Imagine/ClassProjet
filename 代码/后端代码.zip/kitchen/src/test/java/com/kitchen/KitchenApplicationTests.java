package com.kitchen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class KitchenApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    void test2() {
    }

}
