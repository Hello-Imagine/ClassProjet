package com.waiter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaiterApplication {
    public static void main(String[] args) {
        SpringApplication.run(WaiterApplication.class,args);
    }
}
